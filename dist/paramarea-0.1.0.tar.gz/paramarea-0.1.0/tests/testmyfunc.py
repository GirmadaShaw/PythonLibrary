from paramarea import myfunc

def circumcircle():
    assert myfunc.circumcircle( 2.0 ) == 12.566

def areacircle():
    assert myfunc.areacircle( 5.0 ) == 78.5

def perirect():
    assert myfunc.circumrect( 1.0 , 1.0  ) == 4.0

def arearect ():
    assert myfunc.arearect( 1.0  , 1.0 ) == 1.0



