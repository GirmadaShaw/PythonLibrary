import math

def circumcircle( radius : float ) -> float :
    return math.pi * 2 * radius 

def areacircle( radius:float ) -> float :
    return math.pi * ( radius ** 2 )

def perirect( length:float , breadth:float )-> float :
    return 2 * ( length + breadth )

def arearect ( length:float , breadth :float  )-> float :
    return length * breadth

